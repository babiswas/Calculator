package main

import (
	"calculator/calc"
	"context"
	"fmt"
	"log"
	"net"

	"google.golang.org/grpc"
)

type server struct {
	calc.CalculatorServiceServer
}

func (s *server) Sum(ctx context.Context, in *calc.SumRequest) (*calc.SumResponse, error) {
	fmt.Println("Returning the sum of the mumbers:")
	return &calc.SumResponse{
		Result: in.FirstNumber + in.SecondNumber,
	}, nil
}

func main() {
	listener, err := net.Listen("tcp", ":8080")
	if err != nil {
		panic(err)
	}

	s := grpc.NewServer()
	calc.RegisterCalculatorServiceServer(s, &server{})
	if err := s.Serve(listener); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
