package main

import (
	"calculator/calc"
	"context"
	"fmt"
	"log"

	"google.golang.org/grpc"
)

func main() {
	opts := grpc.WithInsecure()
	cc, err := grpc.Dial("localhost:8080", opts)
	if err != nil {
		log.Fatal(err)
	}
	defer cc.Close()

	client := calc.NewCalculatorServiceClient(cc)
	request := &calc.SumRequest{FirstNumber: 1, SecondNumber: 4}

	resp, err := client.Sum(context.Background(), request)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("Sum of the response is => %d ", resp.Result)
}
